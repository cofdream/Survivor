using System;

namespace QFramework
{
    [Obsolete("QConsole=>ConsoleWindow",true)]
    public class QConsole : ConsoleWindow
    {
    }
}